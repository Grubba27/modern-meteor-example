Package["core-runtime"].queue("react-meteor-data",function () {


/* Exports */
return {

}});
