Package["core-runtime"].queue("rspack",function () {/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var EmitterPromise = Package.meteor.EmitterPromise;
var ECMAScript = Package.ecmascript.ECMAScript;
var WebApp = Package.webapp.WebApp;
var WebAppInternals = Package.webapp.WebAppInternals;
var main = Package.webapp.main;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"rspack":{"rspack_server.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rspack/rspack_server.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reifyAsyncResult__) {"use strict"; try {let Meteor;module.link('meteor/meteor',{Meteor(v){Meteor=v}},0);let WebApp,WebAppInternals;module.link('meteor/webapp',{WebApp(v){WebApp=v},WebAppInternals(v){WebAppInternals=v}},1);let path;module.link('path',{default(v){path=v}},2);let parseUrl;module.link('url',{parse(v){parseUrl=v}},3);let RSPACK_CHUNKS_CONTEXT,RSPACK_ASSETS_CONTEXT,RSPACK_HOT_UPDATE_REGEX;module.link("./lib/constants",{RSPACK_CHUNKS_CONTEXT(v){RSPACK_CHUNKS_CONTEXT=v},RSPACK_ASSETS_CONTEXT(v){RSPACK_ASSETS_CONTEXT=v},RSPACK_HOT_UPDATE_REGEX(v){RSPACK_HOT_UPDATE_REGEX=v}},4);if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _async_to_generator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}





// Define constants for both development and production
const rspackChunksContext = process.env.RSPACK_CHUNKS_CONTEXT || RSPACK_CHUNKS_CONTEXT;
const rspackAssetsContext = process.env.RSPACK_ASSETS_CONTEXT || RSPACK_ASSETS_CONTEXT;
/**
 * Regex pattern for rspack bundles
 * @constant {RegExp}
 */ const RSPACK_CHUNKS_REGEX = new RegExp(`^\/${rspackChunksContext}\/(.+)$`);
/**
 * Regex pattern for rspack assets
 * @constant {RegExp}
 */ const RSPACK_ASSETS_REGEX = new RegExp(`^\/${rspackAssetsContext}\/(.+)$`);
if (Meteor.isDevelopment) {
    const { shuffleString } = require('meteor/tools-core/lib/string');
    const { createProxyMiddleware } = require('http-proxy-middleware');
    // Target URL for the Rspack dev server
    const target = `http://localhost:${process.env.RSPACK_DEVSERVER_PORT}`;
    // Proxy HMR websocket upgrade requests
    WebApp.connectHandlers.use('/ws', createProxyMiddleware({
        target,
        ws: true,
        logLevel: 'debug'
    }));
    // Proxy all dev asset requests under the rspack prefix
    WebApp.connectHandlers.use('/__rspack__', createProxyMiddleware({
        target,
        changeOrigin: true,
        ws: true,
        logLevel: 'debug'
    }));
    WebApp.rawConnectHandlers.use((req, res, next)=>{
        // If this request is already under /__rspack__/, don't redirect it again.
        if (req.url.startsWith('/__rspack__/')) {
            return next();
        }
        // 1) match ANY URL whose last segment ends with ".hot-update.js" or ".hot-update.json",
        //    e.g. "/main.ce385971e9f19307.hot-update.js"
        //         "/ui_pages_tasks_tasks-page_jsx.ce385971e9f19307.hot-update.js"
        //         "/foo/bar/baz.1234abcd.hot-update.json"
        const hotUpdate = req.url.match(RSPACK_HOT_UPDATE_REGEX);
        if (hotUpdate) {
            // Redirect "/something.hot-update.js" → "/__rspack__/something.hot-update.js"
            const target = `/__rspack__/${hotUpdate[1]}`;
            res.writeHead(307, {
                Location: target
            });
            return res.end();
        }
        // 2) match "/build-chunks/<anything>"
        const bundlesMatch = req.url.match(RSPACK_CHUNKS_REGEX);
        if (bundlesMatch) {
            // Redirect "/bundles/foo.js" → "/__rspack__/build-chunks/foo.js"
            const target = `/__rspack__/${rspackChunksContext}/${bundlesMatch[1]}`;
            res.writeHead(307, {
                Location: target
            });
            return res.end();
        }
        // 3) match "/build-assets/<anything>"
        const assetsMatch = req.url.match(RSPACK_ASSETS_REGEX);
        if (assetsMatch) {
            // Redirect "/build-assets/foo.js" → "/__rspack__/build-assets/foo.js"
            const target = `/__rspack__/${rspackAssetsContext}/${assetsMatch[1]}`;
            res.writeHead(307, {
                Location: target
            });
            return res.end();
        }
        // Otherwise, let it pass through
        next();
    });
    /**
   * Force client to reload after Rspack server compilation and restart, which doesn’t happen automatically.
   * On each server reload, generate a new client hash once to force Meteor’s client reload.
   * After the first reload, apply Meteor's default behavior.
   */ function enableClientReloadOnServerStart() {
        Meteor.startup(()=>{
            const originalCalc = WebApp.calculateClientHashReplaceable;
            let hasShuffled = false;
            let cachedHash = {};
            let prevRealHash = {};
            WebApp.calculateClientHashReplaceable = function(...args) {
                const arch = args[0];
                const realHash = originalCalc.apply(this, args);
                if (prevRealHash[arch] && realHash !== prevRealHash[arch]) {
                    prevRealHash[arch] = realHash;
                    return realHash;
                }
                prevRealHash[arch] = realHash;
                if (cachedHash[arch] == null) {
                    cachedHash[arch] = shuffleString(realHash);
                    hasShuffled = true;
                }
                return cachedHash[arch];
            };
        });
    }
    // Enable client reload on server startup
    enableClientReloadOnServerStart();
}
/**
 * Register a single rspack static asset with WebAppInternals.staticFilesByArch
 * @param {string} arch - The architecture to register the asset for
 * @param {string} pathname - The pathname of the asset
 * @param {string} filePath - The absolute path to the asset on disk
 * @returns {Object} The static file info object
 */ function registerRspackStaticAsset(arch, pathname, filePath) {
    // Ensure the architecture exists in staticFilesByArch
    if (!WebAppInternals.staticFilesByArch[arch]) {
        WebAppInternals.staticFilesByArch[arch] = Object.create(null);
    }
    // Get the static files object for this architecture
    const staticFiles = WebAppInternals.staticFilesByArch[arch];
    // Skip if already registered
    if (staticFiles[pathname]) {
        // Ensure the entry is marked as cacheable
        staticFiles[pathname].cacheable = true;
        return staticFiles[pathname];
    }
    // Determine file type based on extension
    const type = pathname.endsWith(".js") ? "js" : pathname.endsWith(".css") ? "css" : pathname.endsWith(".json") ? "json" : undefined;
    // Extract hash from filename (assuming it's the second part after splitting by '.')
    const filename = pathname.split("/").pop();
    const hash = filename.split(".")[1];
    // Register the asset
    staticFiles[pathname] = {
        absolutePath: filePath,
        cacheable: true,
        hash,
        type
    };
    return staticFiles[pathname];
}
// Store the original staticFilesMiddleware
const originalStaticFilesMiddleware = WebAppInternals.staticFilesMiddleware;
// Handle rspack assets on-demand to add Meteor's static files headers
WebAppInternals.staticFilesMiddleware = function(staticFilesByArch, req, res, next) {
    return _async_to_generator(function*() {
        const pathname = parseUrl(req.url).pathname;
        try {
            // Check if this is a rspack asset request
            const chunksMatch = pathname.match(RSPACK_CHUNKS_REGEX);
            const assetsMatch = pathname.match(RSPACK_ASSETS_REGEX);
            if (chunksMatch || assetsMatch) {
                const cwd = process.cwd();
                const architectures = [
                    "web.browser",
                    "web.browser.legacy",
                    "web.cordova"
                ];
                WebApp.categorizeRequest(req);
                // Try to find the file on disk
                const context = chunksMatch ? rspackChunksContext : rspackAssetsContext;
                const filename = chunksMatch ? chunksMatch[1] : assetsMatch[1];
                const filePath = path.join(cwd, context, filename);
                architectures.forEach((archName)=>{
                    registerRspackStaticAsset(archName, pathname, filePath);
                });
            }
        } catch (e) {
            console.error(`Error handling rspack asset: ${e.message}`);
        }
        // Call the original middleware
        return originalStaticFilesMiddleware(staticFilesByArch, req, res, next);
    })();
};
//*/
__reifyAsyncResult__();} catch (_reifyError) { __reifyAsyncResult__(_reifyError); }}, { self: this, async: false });
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"lib":{"constants.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// packages/rspack/lib/constants.js                                                                                  //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({DEFAULT_RSPACK_VERSION:()=>DEFAULT_RSPACK_VERSION,DEFAULT_METEOR_RSPACK_VERSION:()=>DEFAULT_METEOR_RSPACK_VERSION,DEFAULT_METEOR_RSPACK_REACT_HMR_VERSION:()=>DEFAULT_METEOR_RSPACK_REACT_HMR_VERSION,DEFAULT_METEOR_RSPACK_REACT_REFRESH_VERSION:()=>DEFAULT_METEOR_RSPACK_REACT_REFRESH_VERSION,DEFAULT_METEOR_RSPACK_SWC_LOADER_VERSION:()=>DEFAULT_METEOR_RSPACK_SWC_LOADER_VERSION,DEFAULT_METEOR_RSPACK_SWC_HELPERS_VERSION:()=>DEFAULT_METEOR_RSPACK_SWC_HELPERS_VERSION,DEFAULT_RSDOCTOR_RSPACK_PLUGIN_VERSION:()=>DEFAULT_RSDOCTOR_RSPACK_PLUGIN_VERSION,GLOBAL_STATE_KEYS:()=>GLOBAL_STATE_KEYS,RSPACK_BUILD_CONTEXT:()=>RSPACK_BUILD_CONTEXT,RSPACK_ASSETS_CONTEXT:()=>RSPACK_ASSETS_CONTEXT,RSPACK_CHUNKS_CONTEXT:()=>RSPACK_CHUNKS_CONTEXT,RSPACK_DOCTOR_CONTEXT:()=>RSPACK_DOCTOR_CONTEXT,RSPACK_HOT_UPDATE_REGEX:()=>RSPACK_HOT_UPDATE_REGEX,FILE_ROLE:()=>FILE_ROLE},true);var _Plugin;
/**
 * @module constants
 * @description Constants and global state keys for Rspack plugin
 */ const DEFAULT_RSPACK_VERSION = '1.6.5';
const DEFAULT_METEOR_RSPACK_VERSION = '0.2.54';
const DEFAULT_METEOR_RSPACK_REACT_HMR_VERSION = '1.4.3';
const DEFAULT_METEOR_RSPACK_REACT_REFRESH_VERSION = '0.17.0';
const DEFAULT_METEOR_RSPACK_SWC_LOADER_VERSION = '0.2.6';
const DEFAULT_METEOR_RSPACK_SWC_HELPERS_VERSION = '0.5.17';
const DEFAULT_RSDOCTOR_RSPACK_PLUGIN_VERSION = '1.2.3';
/**
 * Global state keys used for storing and retrieving state across the application
 * @constant {Object}
 * @property {string} CLIENT_PROCESS - Key for storing the client process
 * @property {string} SERVER_PROCESS - Key for storing the server process
 * @property {string} RSPACK_INSTALLATION_CHECKED - Key for tracking if Rspack installation was checked
 * @property {string} IS_REACT_ENABLED - Key for tracking if React is enabled
 * @property {string} INITIAL_ENTRYPONTS - Key for storing initial entrypoints
 * @property {string} CLIENT_FIRST_COMPILE - Key for tracking client first compilation state
 * @property {string} SERVER_FIRST_COMPILE - Key for tracking server first compilation state
 * @property {string} BUILD_CONTEXT_FILES_CLEANED - Key for tracking if build context files have been cleaned
 */ const GLOBAL_STATE_KEYS = {
    CLIENT_PROCESS: 'rspack.clientProcess',
    SERVER_PROCESS: 'rspack.serverProcess',
    RSPACK_INSTALLATION_CHECKED: 'rspack.rspackInstallationChecked',
    RSPACK_REACT_INSTALLATION_CHECKED: 'rspack.rspackReactInstallationChecked',
    RSPACK_DOCTOR_INSTALLATION_CHECKED: 'rspack.rspackDoctorInstallationChecked',
    REACT_CHECKED: 'rspack.reactChecked',
    TYPESCRIPT_CHECKED: 'rspack.typescriptChecked',
    ANGULAR_CHECKED: 'rspack.angularChecked',
    INITIAL_ENTRYPONTS: 'meteor.initialEntrypoints',
    CLIENT_FIRST_COMPILE: 'rspack.clientFirstCompile',
    SERVER_FIRST_COMPILE: 'rspack.serverFirstCompile',
    BUILD_CONTEXT_FILES_CLEANED: 'rspack.buildContextFilesCleaned'
};
const meteorConfig = typeof Plugin !== 'undefined' ? (_Plugin = Plugin) === null || _Plugin === void 0 ? void 0 : _Plugin.getMeteorConfig() : null;
/**
 * Directory name for Rspack build context
 * Can be overridden with RSPACK_BUILD_CONTEXT environment variable
 * @constant {string}
 */ const RSPACK_BUILD_CONTEXT = (meteorConfig === null || meteorConfig === void 0 ? void 0 : meteorConfig.buildContext) || process.env.RSPACK_BUILD_CONTEXT || '_build';
process.env.RSPACK_BUILD_CONTEXT = RSPACK_BUILD_CONTEXT;
/**
 * Directory name for Rspack assets context
 * Can be overridden with RSPACK_ASSETS_CONTEXT environment variable
 * @constant {string}
 */ const RSPACK_ASSETS_CONTEXT = (meteorConfig === null || meteorConfig === void 0 ? void 0 : meteorConfig.assetsContext) || process.env.RSPACK_ASSETS_CONTEXT || 'build-assets';
process.env.RSPACK_ASSETS_CONTEXT = RSPACK_ASSETS_CONTEXT;
/**
 * Directory name for Rspack bundles context
 * Can be overridden with RSPACK_ASSETS_CONTEXT environment variable
 * @constant {string}
 */ const RSPACK_CHUNKS_CONTEXT = (meteorConfig === null || meteorConfig === void 0 ? void 0 : meteorConfig.chunksContext) || process.env.RSPACK_CHUNKS_CONTEXT || 'build-chunks';
process.env.RSPACK_CHUNKS_CONTEXT = RSPACK_CHUNKS_CONTEXT;
/**
 * Directory name for Rspack doctor context
 * @type {string}
 */ const RSPACK_DOCTOR_CONTEXT = '.rsdoctor';
/**
 * Regex pattern for hot update files
 * @constant {RegExp}
 */ const RSPACK_HOT_UPDATE_REGEX = /^\/(.+\.hot-update\.(?:json|js))$/;
const FILE_ROLE = {
    build: 'build',
    entry: 'entry',
    run: 'run',
    output: 'output'
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"node_modules":{"http-proxy-middleware":{"package.json":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// node_modules/meteor/rspack/node_modules/http-proxy-middleware/package.json                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.exports = {
  "name": "http-proxy-middleware",
  "version": "3.0.5",
  "main": "dist/index.js"
};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dist":{"index.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// node_modules/meteor/rspack/node_modules/http-proxy-middleware/dist/index.js                                       //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.useNode();
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});


/* Exports */
return {
  require: require,
  eagerModulePaths: [
    "/node_modules/meteor/rspack/rspack_server.js"
  ],
  mainModulePath: "/node_modules/meteor/rspack/rspack_server.js"
}});

//# sourceURL=meteor://💻app/packages/rspack.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcnNwYWNrL3JzcGFja19zZXJ2ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3JzcGFjay9saWIvY29uc3RhbnRzLmpzIl0sIm5hbWVzIjpbInJzcGFja0NodW5rc0NvbnRleHQiLCJwcm9jZXNzIiwiZW52IiwiUlNQQUNLX0NIVU5LU19DT05URVhUIiwicnNwYWNrQXNzZXRzQ29udGV4dCIsIlJTUEFDS19BU1NFVFNfQ09OVEVYVCIsIlJTUEFDS19DSFVOS1NfUkVHRVgiLCJSZWdFeHAiLCJSU1BBQ0tfQVNTRVRTX1JFR0VYIiwiTWV0ZW9yIiwiaXNEZXZlbG9wbWVudCIsInNodWZmbGVTdHJpbmciLCJyZXF1aXJlIiwiY3JlYXRlUHJveHlNaWRkbGV3YXJlIiwidGFyZ2V0IiwiUlNQQUNLX0RFVlNFUlZFUl9QT1JUIiwiV2ViQXBwIiwiY29ubmVjdEhhbmRsZXJzIiwidXNlIiwid3MiLCJsb2dMZXZlbCIsImNoYW5nZU9yaWdpbiIsInJhd0Nvbm5lY3RIYW5kbGVycyIsInJlcSIsInJlcyIsIm5leHQiLCJ1cmwiLCJzdGFydHNXaXRoIiwiaG90VXBkYXRlIiwibWF0Y2giLCJSU1BBQ0tfSE9UX1VQREFURV9SRUdFWCIsIndyaXRlSGVhZCIsIkxvY2F0aW9uIiwiZW5kIiwiYnVuZGxlc01hdGNoIiwiYXNzZXRzTWF0Y2giLCJlbmFibGVDbGllbnRSZWxvYWRPblNlcnZlclN0YXJ0Iiwic3RhcnR1cCIsIm9yaWdpbmFsQ2FsYyIsImNhbGN1bGF0ZUNsaWVudEhhc2hSZXBsYWNlYWJsZSIsImhhc1NodWZmbGVkIiwiY2FjaGVkSGFzaCIsInByZXZSZWFsSGFzaCIsImFyZ3MiLCJhcmNoIiwicmVhbEhhc2giLCJhcHBseSIsInJlZ2lzdGVyUnNwYWNrU3RhdGljQXNzZXQiLCJwYXRobmFtZSIsImZpbGVQYXRoIiwiV2ViQXBwSW50ZXJuYWxzIiwic3RhdGljRmlsZXNCeUFyY2giLCJPYmplY3QiLCJjcmVhdGUiLCJzdGF0aWNGaWxlcyIsImNhY2hlYWJsZSIsInR5cGUiLCJlbmRzV2l0aCIsInVuZGVmaW5lZCIsImZpbGVuYW1lIiwic3BsaXQiLCJwb3AiLCJoYXNoIiwiYWJzb2x1dGVQYXRoIiwib3JpZ2luYWxTdGF0aWNGaWxlc01pZGRsZXdhcmUiLCJzdGF0aWNGaWxlc01pZGRsZXdhcmUiLCJwYXJzZVVybCIsImNodW5rc01hdGNoIiwiY3dkIiwiYXJjaGl0ZWN0dXJlcyIsImNhdGVnb3JpemVSZXF1ZXN0IiwiY29udGV4dCIsInBhdGgiLCJqb2luIiwiZm9yRWFjaCIsImFyY2hOYW1lIiwiZSIsImNvbnNvbGUiLCJlcnJvciIsIm1lc3NhZ2UiLCJQbHVnaW4iLCJERUZBVUxUX1JTUEFDS19WRVJTSU9OIiwiREVGQVVMVF9NRVRFT1JfUlNQQUNLX1ZFUlNJT04iLCJERUZBVUxUX01FVEVPUl9SU1BBQ0tfUkVBQ1RfSE1SX1ZFUlNJT04iLCJERUZBVUxUX01FVEVPUl9SU1BBQ0tfUkVBQ1RfUkVGUkVTSF9WRVJTSU9OIiwiREVGQVVMVF9NRVRFT1JfUlNQQUNLX1NXQ19MT0FERVJfVkVSU0lPTiIsIkRFRkFVTFRfTUVURU9SX1JTUEFDS19TV0NfSEVMUEVSU19WRVJTSU9OIiwiREVGQVVMVF9SU0RPQ1RPUl9SU1BBQ0tfUExVR0lOX1ZFUlNJT04iLCJHTE9CQUxfU1RBVEVfS0VZUyIsIkNMSUVOVF9QUk9DRVNTIiwiU0VSVkVSX1BST0NFU1MiLCJSU1BBQ0tfSU5TVEFMTEFUSU9OX0NIRUNLRUQiLCJSU1BBQ0tfUkVBQ1RfSU5TVEFMTEFUSU9OX0NIRUNLRUQiLCJSU1BBQ0tfRE9DVE9SX0lOU1RBTExBVElPTl9DSEVDS0VEIiwiUkVBQ1RfQ0hFQ0tFRCIsIlRZUEVTQ1JJUFRfQ0hFQ0tFRCIsIkFOR1VMQVJfQ0hFQ0tFRCIsIklOSVRJQUxfRU5UUllQT05UUyIsIkNMSUVOVF9GSVJTVF9DT01QSUxFIiwiU0VSVkVSX0ZJUlNUX0NPTVBJTEUiLCJCVUlMRF9DT05URVhUX0ZJTEVTX0NMRUFORUQiLCJtZXRlb3JDb25maWciLCJnZXRNZXRlb3JDb25maWciLCJSU1BBQ0tfQlVJTERfQ09OVEVYVCIsImJ1aWxkQ29udGV4dCIsImFzc2V0c0NvbnRleHQiLCJjaHVua3NDb250ZXh0IiwiUlNQQUNLX0RPQ1RPUl9DT05URVhUIiwiRklMRV9ST0xFIiwiYnVpbGQiLCJlbnRyeSIsInJ1biIsIm91dHB1dCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUF1QztBQUNpQjtBQUNoQztBQUNnQjtBQUtmO0FBRXpCLHVEQUF1RDtBQUN2RCxNQUFNQSxzQkFBc0JDLFFBQVFDLEdBQUcsQ0FBQ0MscUJBQXFCLElBQUlBO0FBQ2pFLE1BQU1DLHNCQUFzQkgsUUFBUUMsR0FBRyxDQUFDRyxxQkFBcUIsSUFBSUE7QUFFakU7OztDQUdDLEdBQ0QsTUFBTUMsc0JBQXNCLElBQUlDLE9BQzlCLENBQUMsR0FBRyxFQUFFUCxvQkFBb0IsT0FBTyxDQUFDO0FBR3BDOzs7Q0FHQyxHQUNELE1BQU1RLHNCQUFzQixJQUFJRCxPQUM5QixDQUFDLEdBQUcsRUFBRUgsb0JBQW9CLE9BQU8sQ0FBQztBQUdwQyxJQUFJSyxPQUFPQyxhQUFhLEVBQUU7SUFDeEIsTUFBTSxFQUFFQyxhQUFhLEVBQUUsR0FBR0MsUUFBUTtJQUNsQyxNQUFNLEVBQUVDLHFCQUFxQixFQUFFLEdBQUdELFFBQVE7SUFFMUMsdUNBQXVDO0lBQ3ZDLE1BQU1FLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRWIsUUFBUUMsR0FBRyxDQUFDYSxxQkFBcUIsRUFBRTtJQUV0RSx1Q0FBdUM7SUFDdkNDLE9BQU9DLGVBQWUsQ0FBQ0MsR0FBRyxDQUFDLE9BQ3pCTCxzQkFBdUI7UUFDckJDO1FBQ0FLLElBQUk7UUFDSkMsVUFBVTtJQUNaO0lBR0YsdURBQXVEO0lBQ3ZESixPQUFPQyxlQUFlLENBQUNDLEdBQUcsQ0FBQyxlQUN6Qkwsc0JBQXNCO1FBQ3BCQztRQUNBTyxjQUFjO1FBQ2RGLElBQUk7UUFDSkMsVUFBVTtJQUNaO0lBR0ZKLE9BQU9NLGtCQUFrQixDQUFDSixHQUFHLENBQUMsQ0FBQ0ssS0FBS0MsS0FBS0M7UUFDdkMsMEVBQTBFO1FBQzFFLElBQUlGLElBQUlHLEdBQUcsQ0FBQ0MsVUFBVSxDQUFDLGlCQUFpQjtZQUN0QyxPQUFPRjtRQUNUO1FBRUEsd0ZBQXdGO1FBQ3hGLGlEQUFpRDtRQUNqRCwwRUFBMEU7UUFDMUUsa0RBQWtEO1FBQ2xELE1BQU1HLFlBQVlMLElBQUlHLEdBQUcsQ0FBQ0csS0FBSyxDQUFDQztRQUNoQyxJQUFJRixXQUFXO1lBQ2IsOEVBQThFO1lBQzlFLE1BQU1kLFNBQVMsQ0FBQyxZQUFZLEVBQUVjLFNBQVMsQ0FBQyxFQUFFLEVBQUU7WUFDNUNKLElBQUlPLFNBQVMsQ0FBQyxLQUFLO2dCQUFFQyxVQUFVbEI7WUFBTztZQUN0QyxPQUFPVSxJQUFJUyxHQUFHO1FBQ2hCO1FBRUEsc0NBQXNDO1FBQ3RDLE1BQU1DLGVBQWVYLElBQUlHLEdBQUcsQ0FBQ0csS0FBSyxDQUFDdkI7UUFDbkMsSUFBSTRCLGNBQWM7WUFDaEIsaUVBQWlFO1lBQ2pFLE1BQU1wQixTQUFTLENBQUMsWUFBWSxFQUFFZCxvQkFBb0IsQ0FBQyxFQUFFa0MsWUFBWSxDQUFDLEVBQUUsRUFBRTtZQUN0RVYsSUFBSU8sU0FBUyxDQUFDLEtBQUs7Z0JBQUVDLFVBQVVsQjtZQUFPO1lBQ3RDLE9BQU9VLElBQUlTLEdBQUc7UUFDaEI7UUFFQSxzQ0FBc0M7UUFDdEMsTUFBTUUsY0FBY1osSUFBSUcsR0FBRyxDQUFDRyxLQUFLLENBQUNyQjtRQUNsQyxJQUFJMkIsYUFBYTtZQUNmLHNFQUFzRTtZQUN0RSxNQUFNckIsU0FBUyxDQUFDLFlBQVksRUFBRVYsb0JBQW9CLENBQUMsRUFBRStCLFdBQVcsQ0FBQyxFQUFFLEVBQUU7WUFDckVYLElBQUlPLFNBQVMsQ0FBQyxLQUFLO2dCQUFFQyxVQUFVbEI7WUFBTztZQUN0QyxPQUFPVSxJQUFJUyxHQUFHO1FBQ2hCO1FBRUEsaUNBQWlDO1FBQ2pDUjtJQUNGO0lBRUE7Ozs7R0FJQyxHQUNELFNBQVNXO1FBQ1AzQixPQUFPNEIsT0FBTyxDQUFDO1lBQ2IsTUFBTUMsZUFBZXRCLE9BQU91Qiw4QkFBOEI7WUFDMUQsSUFBSUMsY0FBYztZQUNsQixJQUFJQyxhQUFhLENBQUM7WUFDbEIsSUFBSUMsZUFBZSxDQUFDO1lBQ3BCMUIsT0FBT3VCLDhCQUE4QixHQUFHLFNBQVUsR0FBR0ksSUFBSTtnQkFDdkQsTUFBTUMsT0FBT0QsSUFBSSxDQUFDLEVBQUU7Z0JBQ3BCLE1BQU1FLFdBQVdQLGFBQWFRLEtBQUssQ0FBQyxJQUFJLEVBQUVIO2dCQUMxQyxJQUFJRCxZQUFZLENBQUNFLEtBQUssSUFBSUMsYUFBYUgsWUFBWSxDQUFDRSxLQUFLLEVBQUU7b0JBQ3pERixZQUFZLENBQUNFLEtBQUssR0FBR0M7b0JBQ3JCLE9BQU9BO2dCQUNUO2dCQUNBSCxZQUFZLENBQUNFLEtBQUssR0FBR0M7Z0JBQ3JCLElBQUlKLFVBQVUsQ0FBQ0csS0FBSyxJQUFJLE1BQU07b0JBQzVCSCxVQUFVLENBQUNHLEtBQUssR0FBR2pDLGNBQWNrQztvQkFDakNMLGNBQWM7Z0JBQ2hCO2dCQUNBLE9BQU9DLFVBQVUsQ0FBQ0csS0FBSztZQUN6QjtRQUNGO0lBQ0Y7SUFFQSx5Q0FBeUM7SUFDekNSO0FBQ0Y7QUFFQTs7Ozs7O0NBTUMsR0FDRCxTQUFTVywwQkFBMEJILElBQUksRUFBRUksUUFBUSxFQUFFQyxRQUFRO0lBQ3pELHNEQUFzRDtJQUN0RCxJQUFJLENBQUNDLGdCQUFnQkMsaUJBQWlCLENBQUNQLEtBQUssRUFBRTtRQUM1Q00sZ0JBQWdCQyxpQkFBaUIsQ0FBQ1AsS0FBSyxHQUFHUSxPQUFPQyxNQUFNLENBQUM7SUFDMUQ7SUFFQSxvREFBb0Q7SUFDcEQsTUFBTUMsY0FBY0osZ0JBQWdCQyxpQkFBaUIsQ0FBQ1AsS0FBSztJQUUzRCw2QkFBNkI7SUFDN0IsSUFBSVUsV0FBVyxDQUFDTixTQUFTLEVBQUU7UUFDekIsMENBQTBDO1FBQzFDTSxXQUFXLENBQUNOLFNBQVMsQ0FBQ08sU0FBUyxHQUFHO1FBQ2xDLE9BQU9ELFdBQVcsQ0FBQ04sU0FBUztJQUM5QjtJQUVBLHlDQUF5QztJQUN6QyxNQUFNUSxPQUFPUixTQUFTUyxRQUFRLENBQUMsU0FBUyxPQUN0Q1QsU0FBU1MsUUFBUSxDQUFDLFVBQVUsUUFDMUJULFNBQVNTLFFBQVEsQ0FBQyxXQUFXLFNBQVNDO0lBRTFDLG9GQUFvRjtJQUNwRixNQUFNQyxXQUFXWCxTQUFTWSxLQUFLLENBQUMsS0FBS0MsR0FBRztJQUN4QyxNQUFNQyxPQUFPSCxTQUFTQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUU7SUFFbkMscUJBQXFCO0lBQ3JCTixXQUFXLENBQUNOLFNBQVMsR0FBRztRQUN0QmUsY0FBY2Q7UUFDZE0sV0FBVztRQUNYTztRQUNBTjtJQUNGO0lBRUEsT0FBT0YsV0FBVyxDQUFDTixTQUFTO0FBQzlCO0FBRUEsMkNBQTJDO0FBQzNDLE1BQU1nQixnQ0FBZ0NkLGdCQUFnQmUscUJBQXFCO0FBRTNFLHNFQUFzRTtBQUN0RWYsZ0JBQWdCZSxxQkFBcUIsR0FBRyxTQUFlZCxpQkFBaUIsRUFBRTVCLEdBQUcsRUFBRUMsR0FBRyxFQUFFQyxJQUFJOztRQUN0RixNQUFNdUIsV0FBV2tCLFNBQVMzQyxJQUFJRyxHQUFHLEVBQUVzQixRQUFRO1FBRTNDLElBQUk7WUFDRiwwQ0FBMEM7WUFDMUMsTUFBTW1CLGNBQWNuQixTQUFTbkIsS0FBSyxDQUFDdkI7WUFDbkMsTUFBTTZCLGNBQWNhLFNBQVNuQixLQUFLLENBQUNyQjtZQUVuQyxJQUFJMkQsZUFBZWhDLGFBQWE7Z0JBQzlCLE1BQU1pQyxNQUFNbkUsUUFBUW1FLEdBQUc7Z0JBQ3ZCLE1BQU1DLGdCQUFnQjtvQkFBQztvQkFBZTtvQkFBc0I7aUJBQWM7Z0JBQzFFckQsT0FBT3NELGlCQUFpQixDQUFDL0M7Z0JBRXpCLCtCQUErQjtnQkFDL0IsTUFBTWdELFVBQVVKLGNBQWNuRSxzQkFBc0JJO2dCQUNwRCxNQUFNdUQsV0FBWVEsY0FBY0EsV0FBVyxDQUFDLEVBQUUsR0FBR2hDLFdBQVcsQ0FBQyxFQUFFO2dCQUMvRCxNQUFNYyxXQUFXdUIsS0FBS0MsSUFBSSxDQUFDTCxLQUFLRyxTQUFTWjtnQkFFekNVLGNBQWNLLE9BQU8sQ0FBQ0M7b0JBQ3BCNUIsMEJBQTBCNEIsVUFBVTNCLFVBQVVDO2dCQUNoRDtZQUNGO1FBQ0YsRUFBRSxPQUFPMkIsR0FBRztZQUNWQyxRQUFRQyxLQUFLLENBQUMsQ0FBQyw2QkFBNkIsRUFBRUYsRUFBRUcsT0FBTyxFQUFFO1FBQzNEO1FBRUEsK0JBQStCO1FBQy9CLE9BQU9mLDhCQUE4QmIsbUJBQW1CNUIsS0FBS0MsS0FBS0M7SUFDcEU7Ozs7Ozs7Ozs7Ozs7O0lDN0pxRHVEO0FBOUNyRDs7O0NBR0MsR0FFRCxPQUFPLE1BQU1DLHlCQUF5QixDQUFRO0FBRTlDLE9BQU8sTUFBTUMsZ0NBQWdDLEVBQVM7QUFFdEQsT0FBTyxNQUFNQywwQ0FBMEMsQ0FBUTtBQUUvRCxPQUFPLE1BQU1DLDhDQUE4QyxFQUFTO0FBRXBFLE9BQU8sTUFBTUMsMkNBQTJDLENBQVE7QUFFaEUsT0FBTyxNQUFNQyw0Q0FBNEMsRUFBUztBQUVsRSxPQUFPLE1BQU1DLHlDQUF5QyxDQUFRO0FBRTlEOzs7Ozs7Ozs7OztDQVdDLEdBQ0QsT0FBTyxNQUFNQyxjQUFvQjtJQUMvQkMsZ0JBQWdCO0lBQ2hCQyxnQkFBZ0I7SUFDaEJDLDZCQUE2QjtJQUM3QkMsbUNBQW1DO0lBQ25DQyxvQ0FBb0M7SUFDcENDLGVBQWU7SUFDZkMsb0JBQW9CO0lBQ3BCQyxpQkFBaUI7SUFDakJDLG9CQUFvQjtJQUNwQkMsc0JBQXNCO0lBQ3RCQyxzQkFBc0I7SUFDdEJDLDZCQUE2QjtBQUMvQixFQUFFO0FBRUYsTUFBTUMsZUFBZSxPQUFPckIsV0FBVyxlQUFjQSxvRUFBUXNCLGVBQWUsS0FBSztBQUVqRjs7OztDQUlDLEdBQ0QsT0FBTyxNQUFNQyx1QkFDWEYsMEVBQWNHLFlBQVksS0FDMUJ2RyxRQUFRQyxHQUFHLENBQUNxRyxvQkFBb0IsSUFDaEMsRUFBUztBQUVYdEcsUUFBUUMsR0FBRyxDQUFDcUcsb0JBQW9CLEdBQUdBO0FBRW5DOzs7O0NBSUMsR0FDRCxPQUFPLE1BQU1sRyx3QkFDWGdHLDBFQUFjSSxhQUFhLEtBQzNCeEcsUUFBUUMsR0FBRyxDQUFDRyxxQkFBcUIsSUFDakMsUUFBZTtBQUVqQkosUUFBUUMsR0FBRyxDQUFDRyxxQkFBcUIsR0FBR0E7QUFFcEM7Ozs7Q0FJQyxHQUNELE9BQU8sTUFBTUYsd0JBQ1hrRywwRUFBY0ssYUFBYSxLQUMzQnpHLFFBQVFDLEdBQUcsQ0FBQ0MscUJBQXFCLElBQ2pDLFFBQWU7QUFFakJGLFFBQVFDLEdBQUcsQ0FBQ0MscUJBQXFCLEdBQUdBO0FBRXBDOzs7Q0FHQyxHQUNELE9BQU8sTUFBTXdHLHdCQUF3QixLQUFZO0FBRWpEOzs7Q0FHQyxHQUNELE9BQU8sTUFBTTdFLDBCQUEwQiw2QkFBb0M7QUFFM0UsT0FBTyxNQUFNOEUsTUFBWTtJQUN2QkMsT0FBTztJQUNQQyxPQUFPO0lBQ1BDLEtBQUs7SUFDTEMsUUFBUTtBQUNWLEVBQUUiLCJmaWxlIjoiL3BhY2thZ2VzL3JzcGFjay5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IHsgV2ViQXBwLCBXZWJBcHBJbnRlcm5hbHMgfSBmcm9tICdtZXRlb3Ivd2ViYXBwJztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IHsgcGFyc2UgYXMgcGFyc2VVcmwgfSBmcm9tICd1cmwnO1xuaW1wb3J0IHtcbiAgUlNQQUNLX0NIVU5LU19DT05URVhULFxuICBSU1BBQ0tfQVNTRVRTX0NPTlRFWFQsXG4gIFJTUEFDS19IT1RfVVBEQVRFX1JFR0VYLFxufSBmcm9tIFwiLi9saWIvY29uc3RhbnRzXCI7XG5cbi8vIERlZmluZSBjb25zdGFudHMgZm9yIGJvdGggZGV2ZWxvcG1lbnQgYW5kIHByb2R1Y3Rpb25cbmNvbnN0IHJzcGFja0NodW5rc0NvbnRleHQgPSBwcm9jZXNzLmVudi5SU1BBQ0tfQ0hVTktTX0NPTlRFWFQgfHwgUlNQQUNLX0NIVU5LU19DT05URVhUO1xuY29uc3QgcnNwYWNrQXNzZXRzQ29udGV4dCA9IHByb2Nlc3MuZW52LlJTUEFDS19BU1NFVFNfQ09OVEVYVCB8fCBSU1BBQ0tfQVNTRVRTX0NPTlRFWFQ7XG5cbi8qKlxuICogUmVnZXggcGF0dGVybiBmb3IgcnNwYWNrIGJ1bmRsZXNcbiAqIEBjb25zdGFudCB7UmVnRXhwfVxuICovXG5jb25zdCBSU1BBQ0tfQ0hVTktTX1JFR0VYID0gbmV3IFJlZ0V4cChcbiAgYF5cXC8ke3JzcGFja0NodW5rc0NvbnRleHR9XFwvKC4rKSRgLFxuKTtcblxuLyoqXG4gKiBSZWdleCBwYXR0ZXJuIGZvciByc3BhY2sgYXNzZXRzXG4gKiBAY29uc3RhbnQge1JlZ0V4cH1cbiAqL1xuY29uc3QgUlNQQUNLX0FTU0VUU19SRUdFWCA9IG5ldyBSZWdFeHAoXG4gIGBeXFwvJHtyc3BhY2tBc3NldHNDb250ZXh0fVxcLyguKykkYCxcbik7XG5cbmlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkge1xuICBjb25zdCB7IHNodWZmbGVTdHJpbmcgfSA9IHJlcXVpcmUoJ21ldGVvci90b29scy1jb3JlL2xpYi9zdHJpbmcnKTtcbiAgY29uc3QgeyBjcmVhdGVQcm94eU1pZGRsZXdhcmUgfSA9IHJlcXVpcmUoJ2h0dHAtcHJveHktbWlkZGxld2FyZScpO1xuXG4gIC8vIFRhcmdldCBVUkwgZm9yIHRoZSBSc3BhY2sgZGV2IHNlcnZlclxuICBjb25zdCB0YXJnZXQgPSBgaHR0cDovL2xvY2FsaG9zdDoke3Byb2Nlc3MuZW52LlJTUEFDS19ERVZTRVJWRVJfUE9SVH1gO1xuXG4gIC8vIFByb3h5IEhNUiB3ZWJzb2NrZXQgdXBncmFkZSByZXF1ZXN0c1xuICBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3dzJyxcbiAgICBjcmVhdGVQcm94eU1pZGRsZXdhcmUoIHtcbiAgICAgIHRhcmdldCxcbiAgICAgIHdzOiB0cnVlLFxuICAgICAgbG9nTGV2ZWw6ICdkZWJ1ZydcbiAgICB9KVxuICApO1xuXG4gIC8vIFByb3h5IGFsbCBkZXYgYXNzZXQgcmVxdWVzdHMgdW5kZXIgdGhlIHJzcGFjayBwcmVmaXhcbiAgV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy9fX3JzcGFja19fJyxcbiAgICBjcmVhdGVQcm94eU1pZGRsZXdhcmUoe1xuICAgICAgdGFyZ2V0LFxuICAgICAgY2hhbmdlT3JpZ2luOiB0cnVlLFxuICAgICAgd3M6IHRydWUsXG4gICAgICBsb2dMZXZlbDogJ2RlYnVnJyxcbiAgICB9KVxuICApO1xuXG4gIFdlYkFwcC5yYXdDb25uZWN0SGFuZGxlcnMudXNlKChyZXEsIHJlcywgbmV4dCkgPT4ge1xuICAgIC8vIElmIHRoaXMgcmVxdWVzdCBpcyBhbHJlYWR5IHVuZGVyIC9fX3JzcGFja19fLywgZG9uJ3QgcmVkaXJlY3QgaXQgYWdhaW4uXG4gICAgaWYgKHJlcS51cmwuc3RhcnRzV2l0aCgnL19fcnNwYWNrX18vJykpIHtcbiAgICAgIHJldHVybiBuZXh0KCk7XG4gICAgfVxuXG4gICAgLy8gMSkgbWF0Y2ggQU5ZIFVSTCB3aG9zZSBsYXN0IHNlZ21lbnQgZW5kcyB3aXRoIFwiLmhvdC11cGRhdGUuanNcIiBvciBcIi5ob3QtdXBkYXRlLmpzb25cIixcbiAgICAvLyAgICBlLmcuIFwiL21haW4uY2UzODU5NzFlOWYxOTMwNy5ob3QtdXBkYXRlLmpzXCJcbiAgICAvLyAgICAgICAgIFwiL3VpX3BhZ2VzX3Rhc2tzX3Rhc2tzLXBhZ2VfanN4LmNlMzg1OTcxZTlmMTkzMDcuaG90LXVwZGF0ZS5qc1wiXG4gICAgLy8gICAgICAgICBcIi9mb28vYmFyL2Jhei4xMjM0YWJjZC5ob3QtdXBkYXRlLmpzb25cIlxuICAgIGNvbnN0IGhvdFVwZGF0ZSA9IHJlcS51cmwubWF0Y2goUlNQQUNLX0hPVF9VUERBVEVfUkVHRVgpO1xuICAgIGlmIChob3RVcGRhdGUpIHtcbiAgICAgIC8vIFJlZGlyZWN0IFwiL3NvbWV0aGluZy5ob3QtdXBkYXRlLmpzXCIg4oaSIFwiL19fcnNwYWNrX18vc29tZXRoaW5nLmhvdC11cGRhdGUuanNcIlxuICAgICAgY29uc3QgdGFyZ2V0ID0gYC9fX3JzcGFja19fLyR7aG90VXBkYXRlWzFdfWA7XG4gICAgICByZXMud3JpdGVIZWFkKDMwNywgeyBMb2NhdGlvbjogdGFyZ2V0IH0pO1xuICAgICAgcmV0dXJuIHJlcy5lbmQoKTtcbiAgICB9XG5cbiAgICAvLyAyKSBtYXRjaCBcIi9idWlsZC1jaHVua3MvPGFueXRoaW5nPlwiXG4gICAgY29uc3QgYnVuZGxlc01hdGNoID0gcmVxLnVybC5tYXRjaChSU1BBQ0tfQ0hVTktTX1JFR0VYKTtcbiAgICBpZiAoYnVuZGxlc01hdGNoKSB7XG4gICAgICAvLyBSZWRpcmVjdCBcIi9idW5kbGVzL2Zvby5qc1wiIOKGkiBcIi9fX3JzcGFja19fL2J1aWxkLWNodW5rcy9mb28uanNcIlxuICAgICAgY29uc3QgdGFyZ2V0ID0gYC9fX3JzcGFja19fLyR7cnNwYWNrQ2h1bmtzQ29udGV4dH0vJHtidW5kbGVzTWF0Y2hbMV19YDtcbiAgICAgIHJlcy53cml0ZUhlYWQoMzA3LCB7IExvY2F0aW9uOiB0YXJnZXQgfSk7XG4gICAgICByZXR1cm4gcmVzLmVuZCgpO1xuICAgIH1cblxuICAgIC8vIDMpIG1hdGNoIFwiL2J1aWxkLWFzc2V0cy88YW55dGhpbmc+XCJcbiAgICBjb25zdCBhc3NldHNNYXRjaCA9IHJlcS51cmwubWF0Y2goUlNQQUNLX0FTU0VUU19SRUdFWCk7XG4gICAgaWYgKGFzc2V0c01hdGNoKSB7XG4gICAgICAvLyBSZWRpcmVjdCBcIi9idWlsZC1hc3NldHMvZm9vLmpzXCIg4oaSIFwiL19fcnNwYWNrX18vYnVpbGQtYXNzZXRzL2Zvby5qc1wiXG4gICAgICBjb25zdCB0YXJnZXQgPSBgL19fcnNwYWNrX18vJHtyc3BhY2tBc3NldHNDb250ZXh0fS8ke2Fzc2V0c01hdGNoWzFdfWA7XG4gICAgICByZXMud3JpdGVIZWFkKDMwNywgeyBMb2NhdGlvbjogdGFyZ2V0IH0pO1xuICAgICAgcmV0dXJuIHJlcy5lbmQoKTtcbiAgICB9XG5cbiAgICAvLyBPdGhlcndpc2UsIGxldCBpdCBwYXNzIHRocm91Z2hcbiAgICBuZXh0KCk7XG4gIH0pO1xuXG4gIC8qKlxuICAgKiBGb3JjZSBjbGllbnQgdG8gcmVsb2FkIGFmdGVyIFJzcGFjayBzZXJ2ZXIgY29tcGlsYXRpb24gYW5kIHJlc3RhcnQsIHdoaWNoIGRvZXNu4oCZdCBoYXBwZW4gYXV0b21hdGljYWxseS5cbiAgICogT24gZWFjaCBzZXJ2ZXIgcmVsb2FkLCBnZW5lcmF0ZSBhIG5ldyBjbGllbnQgaGFzaCBvbmNlIHRvIGZvcmNlIE1ldGVvcuKAmXMgY2xpZW50IHJlbG9hZC5cbiAgICogQWZ0ZXIgdGhlIGZpcnN0IHJlbG9hZCwgYXBwbHkgTWV0ZW9yJ3MgZGVmYXVsdCBiZWhhdmlvci5cbiAgICovXG4gIGZ1bmN0aW9uIGVuYWJsZUNsaWVudFJlbG9hZE9uU2VydmVyU3RhcnQoKSB7XG4gICAgTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xuICAgICAgY29uc3Qgb3JpZ2luYWxDYWxjID0gV2ViQXBwLmNhbGN1bGF0ZUNsaWVudEhhc2hSZXBsYWNlYWJsZTtcbiAgICAgIGxldCBoYXNTaHVmZmxlZCA9IGZhbHNlO1xuICAgICAgbGV0IGNhY2hlZEhhc2ggPSB7fTtcbiAgICAgIGxldCBwcmV2UmVhbEhhc2ggPSB7fTtcbiAgICAgIFdlYkFwcC5jYWxjdWxhdGVDbGllbnRIYXNoUmVwbGFjZWFibGUgPSBmdW5jdGlvbiAoLi4uYXJncykge1xuICAgICAgICBjb25zdCBhcmNoID0gYXJnc1swXTtcbiAgICAgICAgY29uc3QgcmVhbEhhc2ggPSBvcmlnaW5hbENhbGMuYXBwbHkodGhpcywgYXJncyk7XG4gICAgICAgIGlmIChwcmV2UmVhbEhhc2hbYXJjaF0gJiYgcmVhbEhhc2ggIT09IHByZXZSZWFsSGFzaFthcmNoXSkge1xuICAgICAgICAgIHByZXZSZWFsSGFzaFthcmNoXSA9IHJlYWxIYXNoO1xuICAgICAgICAgIHJldHVybiByZWFsSGFzaDtcbiAgICAgICAgfVxuICAgICAgICBwcmV2UmVhbEhhc2hbYXJjaF0gPSByZWFsSGFzaDtcbiAgICAgICAgaWYgKGNhY2hlZEhhc2hbYXJjaF0gPT0gbnVsbCkge1xuICAgICAgICAgIGNhY2hlZEhhc2hbYXJjaF0gPSBzaHVmZmxlU3RyaW5nKHJlYWxIYXNoKTtcbiAgICAgICAgICBoYXNTaHVmZmxlZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNhY2hlZEhhc2hbYXJjaF07XG4gICAgICB9O1xuICAgIH0pO1xuICB9XG5cbiAgLy8gRW5hYmxlIGNsaWVudCByZWxvYWQgb24gc2VydmVyIHN0YXJ0dXBcbiAgZW5hYmxlQ2xpZW50UmVsb2FkT25TZXJ2ZXJTdGFydCgpO1xufVxuXG4vKipcbiAqIFJlZ2lzdGVyIGEgc2luZ2xlIHJzcGFjayBzdGF0aWMgYXNzZXQgd2l0aCBXZWJBcHBJbnRlcm5hbHMuc3RhdGljRmlsZXNCeUFyY2hcbiAqIEBwYXJhbSB7c3RyaW5nfSBhcmNoIC0gVGhlIGFyY2hpdGVjdHVyZSB0byByZWdpc3RlciB0aGUgYXNzZXQgZm9yXG4gKiBAcGFyYW0ge3N0cmluZ30gcGF0aG5hbWUgLSBUaGUgcGF0aG5hbWUgb2YgdGhlIGFzc2V0XG4gKiBAcGFyYW0ge3N0cmluZ30gZmlsZVBhdGggLSBUaGUgYWJzb2x1dGUgcGF0aCB0byB0aGUgYXNzZXQgb24gZGlza1xuICogQHJldHVybnMge09iamVjdH0gVGhlIHN0YXRpYyBmaWxlIGluZm8gb2JqZWN0XG4gKi9cbmZ1bmN0aW9uIHJlZ2lzdGVyUnNwYWNrU3RhdGljQXNzZXQoYXJjaCwgcGF0aG5hbWUsIGZpbGVQYXRoKSB7XG4gIC8vIEVuc3VyZSB0aGUgYXJjaGl0ZWN0dXJlIGV4aXN0cyBpbiBzdGF0aWNGaWxlc0J5QXJjaFxuICBpZiAoIVdlYkFwcEludGVybmFscy5zdGF0aWNGaWxlc0J5QXJjaFthcmNoXSkge1xuICAgIFdlYkFwcEludGVybmFscy5zdGF0aWNGaWxlc0J5QXJjaFthcmNoXSA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIH1cblxuICAvLyBHZXQgdGhlIHN0YXRpYyBmaWxlcyBvYmplY3QgZm9yIHRoaXMgYXJjaGl0ZWN0dXJlXG4gIGNvbnN0IHN0YXRpY0ZpbGVzID0gV2ViQXBwSW50ZXJuYWxzLnN0YXRpY0ZpbGVzQnlBcmNoW2FyY2hdO1xuXG4gIC8vIFNraXAgaWYgYWxyZWFkeSByZWdpc3RlcmVkXG4gIGlmIChzdGF0aWNGaWxlc1twYXRobmFtZV0pIHtcbiAgICAvLyBFbnN1cmUgdGhlIGVudHJ5IGlzIG1hcmtlZCBhcyBjYWNoZWFibGVcbiAgICBzdGF0aWNGaWxlc1twYXRobmFtZV0uY2FjaGVhYmxlID0gdHJ1ZTtcbiAgICByZXR1cm4gc3RhdGljRmlsZXNbcGF0aG5hbWVdO1xuICB9XG5cbiAgLy8gRGV0ZXJtaW5lIGZpbGUgdHlwZSBiYXNlZCBvbiBleHRlbnNpb25cbiAgY29uc3QgdHlwZSA9IHBhdGhuYW1lLmVuZHNXaXRoKFwiLmpzXCIpID8gXCJqc1wiIDpcbiAgICBwYXRobmFtZS5lbmRzV2l0aChcIi5jc3NcIikgPyBcImNzc1wiIDpcbiAgICAgIHBhdGhuYW1lLmVuZHNXaXRoKFwiLmpzb25cIikgPyBcImpzb25cIiA6IHVuZGVmaW5lZDtcblxuICAvLyBFeHRyYWN0IGhhc2ggZnJvbSBmaWxlbmFtZSAoYXNzdW1pbmcgaXQncyB0aGUgc2Vjb25kIHBhcnQgYWZ0ZXIgc3BsaXR0aW5nIGJ5ICcuJylcbiAgY29uc3QgZmlsZW5hbWUgPSBwYXRobmFtZS5zcGxpdChcIi9cIikucG9wKCk7XG4gIGNvbnN0IGhhc2ggPSBmaWxlbmFtZS5zcGxpdChcIi5cIilbMV07XG5cbiAgLy8gUmVnaXN0ZXIgdGhlIGFzc2V0XG4gIHN0YXRpY0ZpbGVzW3BhdGhuYW1lXSA9IHtcbiAgICBhYnNvbHV0ZVBhdGg6IGZpbGVQYXRoLFxuICAgIGNhY2hlYWJsZTogdHJ1ZSwgLy8gTW9zdCByc3BhY2sgYXNzZXRzIGFyZSBjYWNoZWFibGVcbiAgICBoYXNoLFxuICAgIHR5cGVcbiAgfTtcblxuICByZXR1cm4gc3RhdGljRmlsZXNbcGF0aG5hbWVdO1xufVxuXG4vLyBTdG9yZSB0aGUgb3JpZ2luYWwgc3RhdGljRmlsZXNNaWRkbGV3YXJlXG5jb25zdCBvcmlnaW5hbFN0YXRpY0ZpbGVzTWlkZGxld2FyZSA9IFdlYkFwcEludGVybmFscy5zdGF0aWNGaWxlc01pZGRsZXdhcmU7XG5cbi8vIEhhbmRsZSByc3BhY2sgYXNzZXRzIG9uLWRlbWFuZCB0byBhZGQgTWV0ZW9yJ3Mgc3RhdGljIGZpbGVzIGhlYWRlcnNcbldlYkFwcEludGVybmFscy5zdGF0aWNGaWxlc01pZGRsZXdhcmUgPSBhc3luYyBmdW5jdGlvbihzdGF0aWNGaWxlc0J5QXJjaCwgcmVxLCByZXMsIG5leHQpIHtcbiAgY29uc3QgcGF0aG5hbWUgPSBwYXJzZVVybChyZXEudXJsKS5wYXRobmFtZTtcblxuICB0cnkge1xuICAgIC8vIENoZWNrIGlmIHRoaXMgaXMgYSByc3BhY2sgYXNzZXQgcmVxdWVzdFxuICAgIGNvbnN0IGNodW5rc01hdGNoID0gcGF0aG5hbWUubWF0Y2goUlNQQUNLX0NIVU5LU19SRUdFWCk7XG4gICAgY29uc3QgYXNzZXRzTWF0Y2ggPSBwYXRobmFtZS5tYXRjaChSU1BBQ0tfQVNTRVRTX1JFR0VYKTtcblxuICAgIGlmIChjaHVua3NNYXRjaCB8fCBhc3NldHNNYXRjaCkge1xuICAgICAgY29uc3QgY3dkID0gcHJvY2Vzcy5jd2QoKTtcbiAgICAgIGNvbnN0IGFyY2hpdGVjdHVyZXMgPSBbXCJ3ZWIuYnJvd3NlclwiLCBcIndlYi5icm93c2VyLmxlZ2FjeVwiLCBcIndlYi5jb3Jkb3ZhXCJdO1xuICAgICAgV2ViQXBwLmNhdGVnb3JpemVSZXF1ZXN0KHJlcSk7XG5cbiAgICAgIC8vIFRyeSB0byBmaW5kIHRoZSBmaWxlIG9uIGRpc2tcbiAgICAgIGNvbnN0IGNvbnRleHQgPSBjaHVua3NNYXRjaCA/IHJzcGFja0NodW5rc0NvbnRleHQgOiByc3BhY2tBc3NldHNDb250ZXh0O1xuICAgICAgY29uc3QgZmlsZW5hbWUgPSAoY2h1bmtzTWF0Y2ggPyBjaHVua3NNYXRjaFsxXSA6IGFzc2V0c01hdGNoWzFdKTtcbiAgICAgIGNvbnN0IGZpbGVQYXRoID0gcGF0aC5qb2luKGN3ZCwgY29udGV4dCwgZmlsZW5hbWUpO1xuXG4gICAgICBhcmNoaXRlY3R1cmVzLmZvckVhY2goYXJjaE5hbWUgPT4ge1xuICAgICAgICByZWdpc3RlclJzcGFja1N0YXRpY0Fzc2V0KGFyY2hOYW1lLCBwYXRobmFtZSwgZmlsZVBhdGgpO1xuICAgICAgfSk7XG4gICAgfVxuICB9IGNhdGNoIChlKSB7XG4gICAgY29uc29sZS5lcnJvcihgRXJyb3IgaGFuZGxpbmcgcnNwYWNrIGFzc2V0OiAke2UubWVzc2FnZX1gKTtcbiAgfVxuXG4gIC8vIENhbGwgdGhlIG9yaWdpbmFsIG1pZGRsZXdhcmVcbiAgcmV0dXJuIG9yaWdpbmFsU3RhdGljRmlsZXNNaWRkbGV3YXJlKHN0YXRpY0ZpbGVzQnlBcmNoLCByZXEsIHJlcywgbmV4dCk7XG59O1xuIiwiLyoqXG4gKiBAbW9kdWxlIGNvbnN0YW50c1xuICogQGRlc2NyaXB0aW9uIENvbnN0YW50cyBhbmQgZ2xvYmFsIHN0YXRlIGtleXMgZm9yIFJzcGFjayBwbHVnaW5cbiAqL1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9SU1BBQ0tfVkVSU0lPTiA9ICcxLjYuNSc7XG5cbmV4cG9ydCBjb25zdCBERUZBVUxUX01FVEVPUl9SU1BBQ0tfVkVSU0lPTiA9ICcwLjIuNTQnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9NRVRFT1JfUlNQQUNLX1JFQUNUX0hNUl9WRVJTSU9OID0gJzEuNC4zJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfTUVURU9SX1JTUEFDS19SRUFDVF9SRUZSRVNIX1ZFUlNJT04gPSAnMC4xNy4wJztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfTUVURU9SX1JTUEFDS19TV0NfTE9BREVSX1ZFUlNJT04gPSAnMC4yLjYnO1xuXG5leHBvcnQgY29uc3QgREVGQVVMVF9NRVRFT1JfUlNQQUNLX1NXQ19IRUxQRVJTX1ZFUlNJT04gPSAnMC41LjE3JztcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfUlNET0NUT1JfUlNQQUNLX1BMVUdJTl9WRVJTSU9OID0gJzEuMi4zJztcblxuLyoqXG4gKiBHbG9iYWwgc3RhdGUga2V5cyB1c2VkIGZvciBzdG9yaW5nIGFuZCByZXRyaWV2aW5nIHN0YXRlIGFjcm9zcyB0aGUgYXBwbGljYXRpb25cbiAqIEBjb25zdGFudCB7T2JqZWN0fVxuICogQHByb3BlcnR5IHtzdHJpbmd9IENMSUVOVF9QUk9DRVNTIC0gS2V5IGZvciBzdG9yaW5nIHRoZSBjbGllbnQgcHJvY2Vzc1xuICogQHByb3BlcnR5IHtzdHJpbmd9IFNFUlZFUl9QUk9DRVNTIC0gS2V5IGZvciBzdG9yaW5nIHRoZSBzZXJ2ZXIgcHJvY2Vzc1xuICogQHByb3BlcnR5IHtzdHJpbmd9IFJTUEFDS19JTlNUQUxMQVRJT05fQ0hFQ0tFRCAtIEtleSBmb3IgdHJhY2tpbmcgaWYgUnNwYWNrIGluc3RhbGxhdGlvbiB3YXMgY2hlY2tlZFxuICogQHByb3BlcnR5IHtzdHJpbmd9IElTX1JFQUNUX0VOQUJMRUQgLSBLZXkgZm9yIHRyYWNraW5nIGlmIFJlYWN0IGlzIGVuYWJsZWRcbiAqIEBwcm9wZXJ0eSB7c3RyaW5nfSBJTklUSUFMX0VOVFJZUE9OVFMgLSBLZXkgZm9yIHN0b3JpbmcgaW5pdGlhbCBlbnRyeXBvaW50c1xuICogQHByb3BlcnR5IHtzdHJpbmd9IENMSUVOVF9GSVJTVF9DT01QSUxFIC0gS2V5IGZvciB0cmFja2luZyBjbGllbnQgZmlyc3QgY29tcGlsYXRpb24gc3RhdGVcbiAqIEBwcm9wZXJ0eSB7c3RyaW5nfSBTRVJWRVJfRklSU1RfQ09NUElMRSAtIEtleSBmb3IgdHJhY2tpbmcgc2VydmVyIGZpcnN0IGNvbXBpbGF0aW9uIHN0YXRlXG4gKiBAcHJvcGVydHkge3N0cmluZ30gQlVJTERfQ09OVEVYVF9GSUxFU19DTEVBTkVEIC0gS2V5IGZvciB0cmFja2luZyBpZiBidWlsZCBjb250ZXh0IGZpbGVzIGhhdmUgYmVlbiBjbGVhbmVkXG4gKi9cbmV4cG9ydCBjb25zdCBHTE9CQUxfU1RBVEVfS0VZUyA9IHtcbiAgQ0xJRU5UX1BST0NFU1M6ICdyc3BhY2suY2xpZW50UHJvY2VzcycsXG4gIFNFUlZFUl9QUk9DRVNTOiAncnNwYWNrLnNlcnZlclByb2Nlc3MnLFxuICBSU1BBQ0tfSU5TVEFMTEFUSU9OX0NIRUNLRUQ6ICdyc3BhY2sucnNwYWNrSW5zdGFsbGF0aW9uQ2hlY2tlZCcsXG4gIFJTUEFDS19SRUFDVF9JTlNUQUxMQVRJT05fQ0hFQ0tFRDogJ3JzcGFjay5yc3BhY2tSZWFjdEluc3RhbGxhdGlvbkNoZWNrZWQnLFxuICBSU1BBQ0tfRE9DVE9SX0lOU1RBTExBVElPTl9DSEVDS0VEOiAncnNwYWNrLnJzcGFja0RvY3Rvckluc3RhbGxhdGlvbkNoZWNrZWQnLFxuICBSRUFDVF9DSEVDS0VEOiAncnNwYWNrLnJlYWN0Q2hlY2tlZCcsXG4gIFRZUEVTQ1JJUFRfQ0hFQ0tFRDogJ3JzcGFjay50eXBlc2NyaXB0Q2hlY2tlZCcsXG4gIEFOR1VMQVJfQ0hFQ0tFRDogJ3JzcGFjay5hbmd1bGFyQ2hlY2tlZCcsXG4gIElOSVRJQUxfRU5UUllQT05UUzogJ21ldGVvci5pbml0aWFsRW50cnlwb2ludHMnLFxuICBDTElFTlRfRklSU1RfQ09NUElMRTogJ3JzcGFjay5jbGllbnRGaXJzdENvbXBpbGUnLFxuICBTRVJWRVJfRklSU1RfQ09NUElMRTogJ3JzcGFjay5zZXJ2ZXJGaXJzdENvbXBpbGUnLFxuICBCVUlMRF9DT05URVhUX0ZJTEVTX0NMRUFORUQ6ICdyc3BhY2suYnVpbGRDb250ZXh0RmlsZXNDbGVhbmVkJyxcbn07XG5cbmNvbnN0IG1ldGVvckNvbmZpZyA9IHR5cGVvZiBQbHVnaW4gIT09ICd1bmRlZmluZWQnID8gUGx1Z2luPy5nZXRNZXRlb3JDb25maWcoKSA6IG51bGw7XG5cbi8qKlxuICogRGlyZWN0b3J5IG5hbWUgZm9yIFJzcGFjayBidWlsZCBjb250ZXh0XG4gKiBDYW4gYmUgb3ZlcnJpZGRlbiB3aXRoIFJTUEFDS19CVUlMRF9DT05URVhUIGVudmlyb25tZW50IHZhcmlhYmxlXG4gKiBAY29uc3RhbnQge3N0cmluZ31cbiAqL1xuZXhwb3J0IGNvbnN0IFJTUEFDS19CVUlMRF9DT05URVhUID1cbiAgbWV0ZW9yQ29uZmlnPy5idWlsZENvbnRleHQgfHxcbiAgcHJvY2Vzcy5lbnYuUlNQQUNLX0JVSUxEX0NPTlRFWFQgfHxcbiAgJ19idWlsZCc7XG5cbnByb2Nlc3MuZW52LlJTUEFDS19CVUlMRF9DT05URVhUID0gUlNQQUNLX0JVSUxEX0NPTlRFWFQ7XG5cbi8qKlxuICogRGlyZWN0b3J5IG5hbWUgZm9yIFJzcGFjayBhc3NldHMgY29udGV4dFxuICogQ2FuIGJlIG92ZXJyaWRkZW4gd2l0aCBSU1BBQ0tfQVNTRVRTX0NPTlRFWFQgZW52aXJvbm1lbnQgdmFyaWFibGVcbiAqIEBjb25zdGFudCB7c3RyaW5nfVxuICovXG5leHBvcnQgY29uc3QgUlNQQUNLX0FTU0VUU19DT05URVhUID1cbiAgbWV0ZW9yQ29uZmlnPy5hc3NldHNDb250ZXh0IHx8XG4gIHByb2Nlc3MuZW52LlJTUEFDS19BU1NFVFNfQ09OVEVYVCB8fFxuICAnYnVpbGQtYXNzZXRzJztcblxucHJvY2Vzcy5lbnYuUlNQQUNLX0FTU0VUU19DT05URVhUID0gUlNQQUNLX0FTU0VUU19DT05URVhUO1xuXG4vKipcbiAqIERpcmVjdG9yeSBuYW1lIGZvciBSc3BhY2sgYnVuZGxlcyBjb250ZXh0XG4gKiBDYW4gYmUgb3ZlcnJpZGRlbiB3aXRoIFJTUEFDS19BU1NFVFNfQ09OVEVYVCBlbnZpcm9ubWVudCB2YXJpYWJsZVxuICogQGNvbnN0YW50IHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBjb25zdCBSU1BBQ0tfQ0hVTktTX0NPTlRFWFQgPVxuICBtZXRlb3JDb25maWc/LmNodW5rc0NvbnRleHQgfHxcbiAgcHJvY2Vzcy5lbnYuUlNQQUNLX0NIVU5LU19DT05URVhUIHx8XG4gICdidWlsZC1jaHVua3MnO1xuXG5wcm9jZXNzLmVudi5SU1BBQ0tfQ0hVTktTX0NPTlRFWFQgPSBSU1BBQ0tfQ0hVTktTX0NPTlRFWFQ7XG5cbi8qKlxuICogRGlyZWN0b3J5IG5hbWUgZm9yIFJzcGFjayBkb2N0b3IgY29udGV4dFxuICogQHR5cGUge3N0cmluZ31cbiAqL1xuZXhwb3J0IGNvbnN0IFJTUEFDS19ET0NUT1JfQ09OVEVYVCA9ICcucnNkb2N0b3InO1xuXG4vKipcbiAqIFJlZ2V4IHBhdHRlcm4gZm9yIGhvdCB1cGRhdGUgZmlsZXNcbiAqIEBjb25zdGFudCB7UmVnRXhwfVxuICovXG5leHBvcnQgY29uc3QgUlNQQUNLX0hPVF9VUERBVEVfUkVHRVggPSAvXlxcLyguK1xcLmhvdC11cGRhdGVcXC4oPzpqc29ufGpzKSkkLztcblxuZXhwb3J0IGNvbnN0IEZJTEVfUk9MRSA9IHtcbiAgYnVpbGQ6ICdidWlsZCcsXG4gIGVudHJ5OiAnZW50cnknLFxuICBydW46ICdydW4nLFxuICBvdXRwdXQ6ICdvdXRwdXQnLFxufTtcbiJdfQ==
